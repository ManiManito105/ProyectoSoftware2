/*
 * index-algorithm.js
 * Extracto limpio y optimizado del algoritmo JS usado en templates/index.html
 * Contiene: storage, apiCall (con timeout y refresh), loadDashboard optimizada,
 * helpers (formatDate, formatCurrency, safeName) y render mínimo para el dashboard.
 */

const API_BASE = 'http://localhost:5000/api';

// --- Storage wrapper ---
const storage = {
  getToken: () => localStorage.getItem('authToken'),
  setToken: (t) => localStorage.setItem('authToken', t),
  removeToken: () => localStorage.removeItem('authToken'),
  getUser: () => JSON.parse(localStorage.getItem('userInfo') || 'null'),
  setUser: (u) => localStorage.setItem('userInfo', JSON.stringify(u)),
  removeUser: () => localStorage.removeItem('userInfo'),
  getLastSection: () => localStorage.getItem('lastSection') || 'dashboard',
  setLastSection: (s) => localStorage.setItem('lastSection', s)
};

// --- Helpers ---
function formatCurrency(amount) {
  return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(amount || 0);
}

function formatDate(dateString) {
  if (!dateString) return '';
  try {
    let s = String(dateString);
    s = s.replace(/(\.\d{3})\d+/, '$1');
    let d = new Date(s);
    if (isNaN(d)) {
      s = s.replace(/\.\d+/, '');
      d = new Date(s);
    }
    if (isNaN(d)) return '';
    return d.toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) { console.error('formatDate error', e); return ''; }
}

function safeName(mixed, keys = ['nombre', 'codigo']) {
  if (!mixed) return 'N/A';
  if (typeof mixed === 'string') return mixed;
  for (const k of keys) if (mixed[k]) return mixed[k];
  return String(mixed.id || JSON.stringify(mixed));
}

// --- API layer (optimized) ---
async function apiCall(endpoint, { method = 'GET', body = null, headers = {}, timeout = 10000 } = {}) {
  const token = storage.getToken();
  const url = `${API_BASE}${endpoint}`;
  const opts = { method, headers: { 'Content-Type': 'application/json', ...headers } };
  if (body) opts.body = JSON.stringify(body);
  if (token) opts.headers.Authorization = `Bearer ${token}`;

  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  opts.signal = controller.signal;

  try {
    let res = await fetch(url, opts);
    clearTimeout(id);
    if (res.status === 401) {
      const refreshed = await refreshToken();
      if (refreshed.success) {
        opts.headers.Authorization = `Bearer ${refreshed.token}`;
        res = await fetch(url, opts);
      } else {
        redirectToLogin();
        throw new Error('Sesión expirada');
      }
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `HTTP ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    if (err.name === 'AbortError') throw new Error('Request timed out');
    throw err;
  }
}

async function refreshToken() {
  try {
    const token = storage.getToken();
    if (!token) return { success: false };
    const res = await fetch(`${API_BASE}/verify`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token })
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    if (data.token) storage.setToken(data.token);
    if (data.user) storage.setUser(data.user);
    return { success: true, token: data.token };
  } catch (e) { console.error('refreshToken error', e); return { success: false }; }
}

function redirectToLogin() {
  storage.removeToken(); storage.removeUser();
  const login = document.getElementById('login-page');
  const app = document.getElementById('app');
  if (login) login.style.display = 'flex';
  if (app) app.style.display = 'none';
}

// --- Authentication helpers ---
async function login(username, password) {
  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    storage.setToken(data.access_token);
    storage.setUser(data.usuario);
    return { success: true, user: data.usuario };
  } catch (e) { console.error('login error', e); return { success: false, error: e.message }; }
}

function logout() {
  storage.removeToken(); storage.removeUser(); redirectToLogin();
}

// --- Data loaders (concise) ---
async function loadProducts({ limit = null, stock_bajo = false } = {}) {
  let q = '/productos';
  const params = [];
  if (stock_bajo) params.push('stock_bajo=true');
  if (limit) params.push(`limit=${limit}`);
  if (params.length) q += '?' + params.join('&');
  const resp = await apiCall(q);
  if (resp && resp.productos) return { success: true, data: resp.productos };
  if (Array.isArray(resp)) return { success: true, data: resp };
  return { success: false };
}

async function loadDashboard() {
  const resp = await apiCall('/dashboard');
  if (!resp || !resp.resumen) throw new Error('Invalid dashboard response');
  const resumen = resp.resumen;
  let productosCriticos = Array.isArray(resp.productos_criticos) ? resp.productos_criticos : [];

  if ((!productosCriticos || productosCriticos.length === 0) && resumen.productos_stock_bajo > 0) {
    try {
      // Prefer backend filter if available; fall back to client-side filter
      const pr = await loadProducts({ limit: 100 });
      const list = pr.success ? pr.data : [];
      productosCriticos = list.filter(p => (p.stock_actual || 0) < (p.stock_minimo || 0)).slice(0, 5);
    } catch (e) { console.error('loadDashboard - fallback products fetch failed', e); }
  }

  return { success: true, data: { estadisticas: {
    total_productos: resumen.total_productos,
    productos_stock_bajo: resumen.productos_stock_bajo,
    movimientos_hoy: resumen.movimientos_hoy,
    valor_inventario: resumen.valor_inventario
  }, movimientos_recientes: resp.movimientos_recientes || [], productos_stock_bajo: productosCriticos } };
}

// --- Minimal render helpers (dashboard) ---
function renderRecentMovements(movements) {
  const tbody = document.getElementById('recent-movements-table');
  if (!tbody) return;
  if (!movements || movements.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">No hay movimientos recientes</td></tr>';
    return;
  }
  tbody.innerHTML = movements.map(m => `<tr>
    <td>${safeName(m.producto)}</td>
    <td><span class="badge ${((m.tipo_movimiento && m.tipo_movimiento.signo===1) || m.tipo==='Entrada') ? 'success':'danger'}">${m.tipo_movimiento ? m.tipo_movimiento.nombre : (m.tipo || (m.signo===1?'Entrada':'Salida'))}</span></td>
    <td>${m.cantidad||0}</td>
    <td>${formatDate(m.created_at||m.fecha)}</td>
    <td>${safeName(m.usuario, ['nombre_completo','username'])}</td>
  </tr>`).join('');
}

function renderLowStock(products) {
  const tbody = document.getElementById('low-stock-table');
  if (!tbody) return;
  if (!products || products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center">No hay productos con stock bajo</td></tr>';
    return;
  }
  tbody.innerHTML = products.map(p => `<tr>
    <td>${p.nombre || p.codigo || 'N/A'}</td>
    <td>${p.stock_actual||0}</td>
    <td>${p.stock_minimo||0}</td>
    <td><span class="badge danger">Stock Bajo</span></td>
  </tr>`).join('');
}

function updateDashboardUI(data) {
  if (!data || !data.success) { console.error('updateDashboardUI - invalid data'); return; }
  const stats = data.data.estadisticas || {};
  document.getElementById('total-products').textContent = stats.total_productos || 0;
  document.getElementById('low-stock-products').textContent = stats.productos_stock_bajo || 0;
  document.getElementById('today-movements').textContent = stats.movimientos_hoy || 0;
  document.getElementById('inventory-value').textContent = formatCurrency(stats.valor_inventario||0);
  renderRecentMovements(data.data.movimientos_recientes || []);
  renderLowStock(data.data.productos_stock_bajo || []);
}

// Export: attach to window for easy use in browser
window.appHelpers = { apiCall, loadDashboard, loadProducts, formatDate, safeName, updateDashboardUI };
